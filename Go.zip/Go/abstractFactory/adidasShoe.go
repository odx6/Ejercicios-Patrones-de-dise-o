package main

type adidasShoe struct {
	shoe
}
