package main

type dress interface {
	getColor() string
}
