<?php
interface Button
{
public function render();
}
interface FormFactory
{
public function createButton();
}
class LoginButton implements Button
{
public function render()
{
return 'Login';
}
}
class RegisterButton implements Button
{
public function render()
{
return 'Register';
}
}
class LoginFactory implements FormFactory
{
public function createButton()
{
return new LoginButton();
}
}
class RegisterFactory implements FormFactory
{
public function createButton()
{
return new RegisterButton();
}
}
// Client
$loginButtonFactory = new LoginFactory();
$button = $loginButtonFactory->createButton();
echo $button->render().'<br>';
$registerButtonFactory1 = new RegisterFactory();
$button1 = $registerButtonFactory1->createButton();
echo $button1->render();