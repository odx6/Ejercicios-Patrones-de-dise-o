<?php

class StrategyContext {
    private $strategy = NULL; 
    
    public function __construct($strategy_ind_id) {
        switch ($strategy_ind_id) {
            case "C": 
                $this->strategy = new StrategyCaps();
            break;
            case "E": 
                $this->strategy = new StrategyExclaim();
            break;
            case "S": 
                $this->strategy = new StrategyStars();
            break;
        }
    }
    public function showBookTitle($book) {
      return $this->strategy->showTitle($book);
    }
}

interface StrategyInterface {
    public function showTitle($book_in);
}
 
class StrategyCaps implements StrategyInterface {
    public function showTitle($book_in) {
        $title = $book_in->getTitle();
     
        return strtoupper ($title);
    }
}

class StrategyExclaim implements StrategyInterface {
    public function showTitle($book_in) {
        $title = $book_in->getTitle();
        
        return Str_replace(' ','!',$title);
    }
}

class StrategyStars implements StrategyInterface {
    public function showTitle($book_in) {
        $title = $book_in->getTitle();
        
        return Str_replace(' ','*',$title);
    }
}

class Book {
    private $author;
    private $title;
    function __construct($title_in, $author_in) {
        $this->author = $author_in;
        $this->title  = $title_in;
    }
    function getAuthor() {
        return $this->author;
    }
    function getTitle() {
        return $this->title;
    }
    function getAuthorAndTitle() {
        return $this->getTitle() . ' by ' . $this->getAuthor();
    }
}

  writeln('Prueba de el patron estrategia  ');
  writeln('');

  $book = new Book('PHP for Cats','Larry Truett');
 
  $strategyContextC = new StrategyContext('C');
  $strategyContextE = new StrategyContext('E');
  $strategyContextS = new StrategyContext('S');
 
  writeln('prueba 1 - muestra el libro en el contexto C');
  writeln($strategyContextC->showBookTitle($book));
  writeln('');

  writeln('prueba 2 - muestra el libro en el contexto E');
  writeln($strategyContextE->showBookTitle($book));
  writeln('');
 
  writeln('prueba 3 - muestra el libro en el contexto S');
  writeln($strategyContextS->showBookTitle($book));
  writeln('');

  writeln('Fin de la prueba ');

  function writeln($line_in) {
    echo $line_in."<br/>";
  }

?>