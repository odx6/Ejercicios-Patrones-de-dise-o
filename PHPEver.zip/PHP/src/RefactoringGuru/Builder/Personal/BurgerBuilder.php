<?php
class Burger {
    private $patty;
    private $toppings = [];
    private $bun;

    public function setBun(string $bun): void {
        $this->bun = $bun;
    }

    public function setPatty(string $patty): void {
        $this->patty = $patty;
    }

    public function addToppings(array $toppings): void {
        $this->toppings = $toppings;
    }
}

abstract class BurgerBuilder {
    protected $burger;

    public function createBurger(): void {
        $this->burger = new Burger();
    }

    public function getBurger(): Burger {
        return $this->burger;
    }

    abstract public function prepareBun(): void;
    abstract public function cookPatty(): void;
    abstract public function putToppings(): void;
}
//Hamburguesa Vegetariana
class VeggieBurgerBuilder extends BurgerBuilder {
    public function prepareBun(): void {
        $this->burger->setBun('brioche');
    }

    public function cookPatty(): void {
        $this->burger->setPatty('halloumi');
    }

    public function putToppings(): void {
        $this->burger->addToppings(['cauliflower', 'tomato', 'onion', 'cheese']);
    }
}
//Clase Para una hamburguesa americana 
class AmericanBurgerBuilder extends BurgerBuilder {
    public function prepareBun(): void {
        $this->burger->setBun('slider');
    }

    public function cookPatty(): void {
        $this->burger->setPatty('beef');
    }

    public function putToppings(): void {
        $this->burger->addToppings(['tomato', 'cheese', 'onion', 'pickles', 'bacon']);
    }
}
//controla la construccion de la hamburguesa
class BurgerChef {
    public function makeBurger(BurgerBuilder $builder): Burger {
        $builder->createBurger();
        $builder->prepareBun();
        $builder->cookPatty();
        $builder->putToppings();

        return $builder->getBurger();
    }
}
//Client
$chef = new BurgerChef();
$vegieBurger = $chef->makeBurger(new VeggieBurgerBuilder());
$americanBurger = $chef->makeBurger(new AmericanBurgerBuilder());



echo serialize($vegieBurger).'<br>';
echo serialize($americanBurger);

?>