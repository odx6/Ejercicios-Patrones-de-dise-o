<?php

namespace RefactoringGuru\Singleton\RealWorld;

/**
 * Singleton Design Pattern
 *
 * Intent: Lets you ensure that a class has only one instance, while providing a
 * global access point to this instance.
 *
 * Example: The Singleton pattern is notorious for limiting code reuse and
 * complicating unit testing. However, it is still very useful in some cases. In
 * particular, it's handy when you need to control some shared resources. For
 * example, a global logging object that has to control the access to a log
 * file. Another good example: a shared runtime configuration storage.
 */

/**
 * If you need to support several types of Singletons in your app, you can
 * define the basic features of the Singleton in a base class, while moving the
 * actual business logic (like logging) to subclasses.
 */
class Singleton
{
    /**
     * The actual singleton's instance almost always resides inside a static
     * field. In this case, the static field is an array, where each subclass of
     * the Singleton stores its own instance.
     */
    private static $instances = [];

    /**
     * Singleton's constructor should not be public. However, it can't be
     * private either if we want to allow subclassing.
     */
    protected function __construct() { }

    /**
     * Cloning and unserialization are not permitted for singletons.
     */
    protected function __clone() { }

    public function __wakeup()
    {
        throw new \Exception("Cannot unserialize singleton");
    }

    /**
     * The method you use to get the Singleton's instance.
     */
    public static function getInstance()
    {
        $subclass = static::class;
        if (!isset(self::$instances[$subclass])) {
            // Note that here we use the "static" keyword instead of the actual
            // class name. In this context, the "static" keyword means "the name
            // of the current class". That detail is important because when the
            // method is called on the subclass, we want an instance of that
            // subclass to be created here.

            self::$instances[$subclass] = new static();
        }
        return self::$instances[$subclass];
    }
}


class Perrito extends Singleton {

private $name;
private $color;
protected function __construct() { 
    $this->name='mundial';
    $this->color='rojo';


}
public function setName($name){

    $this->name=$name;
}
public function getName(){
    return $this->name;
}
public function setColor($color){
    $this->color=$color;
}
public function getColor(){
    return $this->color;
}

}
//Code Client 

$perro1 =Perrito::getInstance();
$perro1->setName('Goku');
$perro1->setColor('Naranja');
echo '<br> Instance the Dog 1 <br>';
 echo $perro1->getName().'<br>';
 echo $perro1->getColor().'<br>';
$perro2=Perrito::getInstance();
if ($perro1 === $perro2) {
    echo "Logger has a single instance.";
} else {
    echo "Loggers are different.";
}




$perro2->setName('oblak');
$perro2->setColor('Azul');


 echo '<br> Instance the Dog 2 <br>';
 echo $perro2->getName().'<br>';
 echo $perro2->getColor().'<br>';