<?php
// se declara la clase absracta
abstract class BookPrototype {
    protected $title;
    protected $topic;
    abstract function __clone();
    function getTitle() {
        return $this->title;
    }
    function setTitle($titleIn) {
        $this->title = $titleIn;
    }
    function getTopic() {
        return $this->topic;
    }
}
// se declara una clase especifica para libros PHP
class PHPBookPrototype extends BookPrototype {
    function __construct() {
        $this->topic = 'PHP';
    }
    function __clone() {
    }
}
// se declara una clase especifica para libros SQl

class SQLBookPrototype extends BookPrototype {
    function __construct() {
        $this->topic = 'SQL';
    }
    function __clone() {
    }
}
 
  writeln('Prueba Del metodo Prototyoe');
  writeln('');

  $phpProto = new PHPBookPrototype();
  $sqlProto = new SQLBookPrototype();

  $book1 = clone $sqlProto;
  $book1->setTitle('SQL para principiantes');
  writeln('Libro 1 topic: '.$book1->getTopic());
  writeln('Libro 1 title: '.$book1->getTitle());
  writeln('');

  $book2 = clone $phpProto;
  $book2->setTitle('Aprende  PHP 5');
  writeln('Libro 2 topic: '.$book2->getTopic());
  writeln('Libro 2 title: '.$book2->getTitle());
  writeln('');

  $book3 = clone $sqlProto;
  $book3->setTitle('Aprende SQL');
  writeln('Libro 3 topic: '.$book3->getTopic());
  writeln('Libro 3 title: '.$book3->getTitle());
  writeln('');

  writeln('Fin de Prueba protype');

  function writeln($line_in) {
    echo $line_in."<br/>";
  }

?>