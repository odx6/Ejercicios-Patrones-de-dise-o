<?php
//abstract
interface Formatter
{
    public function format(string $text): string;
}
//implementor
class PlainTextFormatter implements Formatter
{
    public function format(string $text): string
    {
        return $text;
    }
}
//implemetor
class HtmlFormatter implements Formatter
{
    public function format(string $text): string
    {
        return sprintf('<p>%s</p>', $text);
    }
}

//abstract
abstract class Service
{
    public function __construct(protected Formatter $implementation)
    {
    }

    final public function setImplementation(Formatter $printer)
    {
        $this->implementation = $printer;
    }

    abstract public function get(): string;
}
//
class HelloWorldService extends Service
{
    public function get(): string
    {
        return $this->implementation->format('Hello World');
    }
}
//


//test
class BridgeTest 
{
    public function testCanPrintUsingThePlainTextFormatter()
    {
        $service = new HelloWorldService(new PlainTextFormatter());
    
          echo $service->get();
    }

    public function testCanPrintUsingTheHtmlFormatter()
    {
        $service = new HelloWorldService(new HtmlFormatter());
        
         echo $service->get();
    }
}
//client code

$test =new BridgeTest();
echo $test->testCanPrintUsingThePlainTextFormatter();
$test->testCanPrintUsingTheHtmlFormatter();