<?php

class Something
{
    public $string;
public function __construct( $message){
        $this->string=$message;
    }

    public function getMessage(){
        return $this->string;
    }
}
interface IAdapter
{
    public function save(Something $something);
}
// Save in Ram memory 
class StoreInMemoryAdapter implements IAdapter
{
    private $data = [];

    public function save(Something $something)
    {
        $this->data[] = $something;
    }
}
// Save in write File 
class StoreInFileAdapter implements IAdapter
{
    public function save(Something $something)
    {
        file_put_contents('file.txt', $something->string.PHP_EOL, FILE_APPEND);
    }
}
//Client Code 
echo '<br> Intnace StoreInMemoryAdapter <br>';

$some= new Something('write 1');

echo $some->getMessage().'<br>';

echo '<br> Intnace StoreInFileAdapter <br>';
$some2= new Something('Hola Como estas');
echo $some2->getMessage().'<br>';

$Memory = new StoreInMemoryAdapter();
$Memory->save($some);

$file =new StoreInFileAdapter();
$file->save($some2);



?>